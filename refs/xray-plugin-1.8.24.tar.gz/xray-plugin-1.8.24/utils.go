// +build !android

package main

func registerControlFunc() {
}
