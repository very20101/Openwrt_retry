# Changelog

## [1.2] - 2024-12-07
### Fixed
- Fixed a bug in query string parsing when escaped quote was present.
- Fixed a bug in query string parsing when multiple equal signs were present.
  Issues reported by [@GitSparTV](https://github.com/GitSparTV) in [#28](https://github.com/golgote/neturl/issues/28).
